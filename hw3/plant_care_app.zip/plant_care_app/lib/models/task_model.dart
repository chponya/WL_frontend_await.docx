class Task {
  String name;
  bool isCompleted;

  Task(this.name, this.isCompleted);
}