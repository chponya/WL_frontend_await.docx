package com.example.navigation_homework

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
